<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../Order.php';

class OrderTest extends TestCase
{
    public function testAddOrderWithMock()
    {
        $pdoMock = $this->createMock(PDO::class);
        $stmtMock = $this->createMock(PDOStatement::class);

        $pdoMock->expects($this->once())->method('prepare')->willReturn($stmtMock);
        $stmtMock->expects($this->once())->method('execute')->willReturn(true);
        $pdoMock->method('exec')->willReturn(0);

        $order = new Order($pdoMock);
        $order->add("Test User", 2, "Burger", 1, "Курьер");
    }

    public function testIntegrationRealDatabase()
    {
        $envFile = __DIR__ . '/../.env.test';
        $env = file_exists($envFile) ? parse_ini_file($envFile) : [];

        $host = $env['DB_HOST'] ?? 'db';
        $db   = $env['DB_NAME'] ?? 'test_db';
        $user = $env['DB_USER'] ?? 'root';
        $pass = $env['DB_PASSWORD'] ?? 'rootpass';

        $dsn = "mysql:host={$host};charset=utf8mb4";

        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db}`");
        $pdo->exec("USE `{$db}`");
        $pdo->exec("DROP TABLE IF EXISTS orders");

        $order = new Order($pdo);
        $order->add("Integration Test", 5, "Pizza", 0, "Самовывоз");

        $stmt = $pdo->query("SELECT * FROM orders");
        $allOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->assertCount(1, $allOrders);
        $this->assertEquals("Integration Test", $allOrders[0]['name']);
    }

    public function testAddOrderError()
    {
        $envFile = __DIR__ . '/../.env.test';
        $env = file_exists($envFile) ? parse_ini_file($envFile) : [];

        $host = $env['DB_HOST'] ?? 'db';
        $db   = $env['DB_NAME'] ?? 'test_db';
        $user = $env['DB_USER'] ?? 'root';
        $pass = $env['DB_PASSWORD'] ?? 'rootpass';

        $dsn = "mysql:host={$host};dbname={$db};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $order = new Order($pdo);

        $this->expectException(PDOException::class);
        $order->add(null, 1, "Sushi", 0, "Курьер");
    }
}