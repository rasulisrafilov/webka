<?php
class Order {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->createTable();
    }

    private function createTable() {
        $sql = "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            quantity INT NOT NULL,
            food VARCHAR(100) NOT NULL,
            extra_sauce TINYINT(1) DEFAULT 0,
            delivery VARCHAR(50) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )";
        $this->pdo->exec($sql);
    }

    public function add($name, $quantity, $food, $extra_sauce, $delivery) {
        $stmt = $this->pdo->prepare(
            "INSERT INTO orders (name, quantity, food, extra_sauce, delivery) VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->execute([$name, $quantity, $food, $extra_sauce, $delivery]);
    }
}