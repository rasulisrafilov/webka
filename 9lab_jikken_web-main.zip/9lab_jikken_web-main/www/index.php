<?php
session_start();
require_once 'vendor/autoload.php';
require_once 'QueueManager.php';

$q = new QueueManager();
$stats = $q->getStats();
?>
<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8"><title>Главная - ЛР 7</title></head>
<body>
    <h2>Система заказов еды (Асинхронная)</h2>

    <div style="background: #f4f4f4; padding: 15px; border: 1px solid #ccc; width: 300px; margin-bottom: 20px;">
        <h3>📊 Статистика очередей:</h3>
        <p>⏳ <b>В очереди Kafka (ожидают):</b> <?= $stats['kafka_waiting'] ?></p>
        <p>🚨 <b>В очереди RabbitMQ (ошибки):</b> <?= $stats['rabbit_errors'] ?></p>
    </div>

    <?php if (isset($_SESSION['success_msg'])): ?>
        <p style="color: green; font-weight: bold;"><?= $_SESSION['success_msg'] ?></p>
        <?php unset($_SESSION['success_msg']); ?>
    <?php endif; ?>

    <a href="form.html">Оформить новый заказ</a> |
    <a href="view.php">История успешных заказов</a>
</body>
</html>